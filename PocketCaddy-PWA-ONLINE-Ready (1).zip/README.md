# Pocket Caddy Web — ONLINE Ready (repack)
Utilise des chemins relatifs pour un déploiement propre sur Vercel. Build command vide, Output `.`.
